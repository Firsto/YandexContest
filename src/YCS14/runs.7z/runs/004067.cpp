
#include <iostream>
#include <string.h>

using namespace std;


const int TEXT_LEN = 21;
const int MAX = 50000;

struct TWord
{
  char Text[TEXT_LEN];
  int F;
  int L; // Length
  int LastNumber;
  bool Valid;
};

int arrlen[8] = {3, 3, 3, 3, 3, 4, 3, 4 };
char arr[8][5] = {"abc", "def", "ghi", "jkl", "mno", "pqrs", "tuv", "wxyz" };

char dev[4] = ".,?";

TWord Words[MAX];
int WordsCount = 0;

TWord * ValidWords[MAX];
int ValidCount = 0;

int Index = 0; // ������� ������
int Len; // ����� �������� �����

int Choice = -1;


bool Slovo = false;
bool Devider = false;

char Result[1000000];  // ����� ���������
int ResLen; // ��� �����

int WordNumber = 1; // ����� �������� �����


char NewWord[21];



void GenArr(bool First)
{
  if(Slovo)
  {
    int max = -1;
    int maxi = -1;
    int maxlast = -1;

    int i, j, q, a;
    bool flag;

    ValidCount = 0;

    for(i = 0; i < WordsCount; i++)
      if(Words[i].L == Len)
      {
        Words[i].Valid = true;
        for(j = 0; j < Len; j++)
        {
          flag = false;

          for(q = 0; q < arrlen[ NewWord[j]-50]; q++)
          {

            if( Words[i].Text[j] == arr[ NewWord[j] - 50 ][q] )
            {
              flag = true;
              break;
            }
          }


          if(!flag)
          {
            Words[i].Valid = false;
            break;
          }

        } // for

        if(Words[i].Valid)
        {
          if(First)
          {
            if ( (Words[i].F > max) ||
                ((Words[i].F == max) && (Words[i].LastNumber > maxlast)) )
            {
              maxi = i;
              max = Words[i].F;
              maxlast = Words[i].LastNumber;
            }

          }
          else
          {
          // ��������� � valid ������
          if(ValidCount == 0)
            ValidWords[0] = &Words[i];
          else
          {

            for( q = 0; q < ValidCount; q++)
            {
              if ( (Words[i].F > ValidWords[q]->F) ||
                   ((Words[i].F == ValidWords[q]->F) && (Words[i].LastNumber > ValidWords[q]->LastNumber)) ) { break; }
            }

            for(a = ValidCount+1; a > q; a--)
              ValidWords[a] = ValidWords[a-1];

            ValidWords[q] = &Words[i];

          }

          ValidCount++;
        }

        } // else
        
      }
      else
        Words[i].Valid = false;


    if((First)&&(max > -1))
    {
      ValidCount = 1;
      ValidWords[0] = &Words[maxi];
    }

    if(ValidCount > 0)
      Choice = 0;

    Slovo = false;

  } // if Slovo

}

void AddWord()
{
  if(Choice > -1)
  {

    if(Devider)
    {
      Result[ResLen] = dev[ Choice ];
      ResLen++;

      Devider = false;
    }
    else
    {
      int i;
      for(i = 0; i < ValidWords[Choice]->L; i++)
        Result[ResLen+i] = ValidWords[Choice]->Text[i];
      ResLen += i;

      ValidWords[Choice]->F++;
      ValidWords[Choice]->LastNumber = WordNumber;

      WordNumber++;

      ValidCount = 0;
    }

    Choice = -1;
  }
}


int main()
{

  char c;

  cin >> WordsCount;

  int i;
  for(i = 0; i < WordsCount; i++)
  {
    Words[i].L++;
    cin >> Words[i].Text;
    Words[i].L = strlen(Words[i].Text);

    cin >> Words[i].F;
  }


  while(cin.get(c))
  {

    if ( (c >= '2') && (c <= '9') )
    {
      if(!Slovo) // �������� �������� ����� �����
      {
        AddWord();

        Slovo = true;
        Len = 0;
      }
      else
        Len++;


      NewWord[Len] = c;

    }
    else
    {
      Len++;


      switch(c)
      {
        case '1':
        {
          GenArr(true);
          AddWord();

          Devider = true;
          Choice = 0;
          ValidCount = 3;

          break;
        }

        case ' ':
        {
          GenArr(true);
          AddWord();

          Result[ResLen] = ' ';
          ResLen++;

          break;
        }

        case '*':
        {
          GenArr(false);
          if(Choice > -1)
          {
            Choice++;
            if(Choice >= ValidCount) Choice = 0;
          }
          break;
        }
      }


    } // else

  }


  if(Choice == -1)
    GenArr(true);

  AddWord();

  for(i = 0; i < ResLen; i++)
    cout.put(Result[i]);

  return 0;
}


